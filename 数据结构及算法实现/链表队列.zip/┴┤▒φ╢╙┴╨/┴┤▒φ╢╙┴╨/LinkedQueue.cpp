#include <iostream>
#include <cstdlib>
using namespace std;
enum Error_code{overflow, underflow, success};

template<typename T>
class Node
{
	template<typename T> friend class LinkedQueue;//declare the LinkedQueue as the friend class
	T data;//to store the values
	Node<T> *next;//point to the next node
	Node();//default constructor
	Node(const T& x, Node* add_on);//create a new node
};

template<typename T>
Node<T>::Node()
{}

template<typename T>
Node<T>::Node(const T &x, Node<T> *add_on)
{
	data = x;
	next = add_on;
}

//definition of linked queue
template<typename T>
class LinkedQueue
{
public:
	LinkedQueue();//constructor with no parameter
	LinkedQueue(const LinkedQueue<T>& queue);//copy constructor
	~LinkedQueue();//destructor, delete the pointer of array
	bool isEmpty() const;//check the queue if it is empty
	int size() const;//get the size of the queue
	void clear();//erase the queue
	Error_code append(const T& x);//add an element to the trail
	Error_code serve();//delete the front element 
	Error_code retrieve(T& x) const;//get the front element
	Error_code serve_and_retrieve(T& x);//delete and get the value of the front element
	void operator =(const LinkedQueue<T> &poriginal);//overload the assign operator
private:
	Node<T> *front;//point to the position before the first element of the queue
	Node<T> *rear;//point to the rear element of the queue
};

template<typename T>
LinkedQueue<T>::LinkedQueue()
{
	front = rear = 0;
}

template<typename T>
LinkedQueue<T>::LinkedQueue(const LinkedQueue<T>& original)
{
	Node<T> *new_copy, *new_original = original.front;
	if(new_original == NULL) front = rear = NULL;
	else
	{
		front = new_copy = new Node<T>(new_original->data, NULL);
		while(new_original->next != NULL)
		{
			new_original = new_original->next;
			new_copy->next = new Node<T>(new_original->data, NULL);
			new_copy = new_copy->next;
			rear = new_copy;
		}
	}
}

template<typename T>
LinkedQueue<T>::~LinkedQueue()
{
	Node<T> *tmp;
	while(!isEmpty())
	{
		tmp = front -> next;
		delete front;
		front = tmp;
	}
}

template<typename T>
bool LinkedQueue<T>::isEmpty() const
{
	return (front)? false : true;
}

template<typename T>
int LinkedQueue<T>::size() const
{
	int len = 1;
	Node<T> *tmp = front;
	while(tmp -> next)
	{
		tmp = tmp -> next;
		len++;
	}
	return len;
}

template<typename T>
void LinkedQueue<T>::clear()
{
	Node<T> *tmp;
	while(front)
	{
		tmp = front -> next;
		delete front;
		front = tmp;
	}
	return ;
}

template<typename T>
Error_code LinkedQueue<T>::append(const T &x)
{
	Node<T> *tmp = new Node<T>;
	tmp -> data = x;
	tmp -> next = NULL;
	if(isEmpty()) front = rear = tmp;
	else {
		rear -> next = tmp;
		rear = tmp;
	}
	return success;
}

template<typename T>
Error_code LinkedQueue<T>::serve()
{
	Node<T> *tmp = front;
	if(isEmpty())
		return underflow;
	else 
	{
		front = front -> next;
		delete tmp;
		return success;
	}
}

template<typename T>
Error_code LinkedQueue<T>::retrieve(T &x) const
{
	if(isEmpty())
		return underflow;
	else 
	{
		x = front -> data;
		return success;
	}
}

template<typename T>
Error_code LinkedQueue<T>::serve_and_retrieve(T &x)
{
	Node<T> *tmp = front;
	if(isEmpty()) 
		return underflow;
	else 
	{
		x = front -> data;
		front = front -> next;
		delete tmp;
		return success;
	}
}

template<typename T>
void LinkedQueue<T>::operator =(const LinkedQueue<T> &original)
{
	Node *new_front, *new_copy, *new_original = original.front;
	if(new_original == NULL) front = rear = NULL;
	else
	{
		new_front = new_copy = new Node<T>(new_original->data, NULL);
		while(new_original->next != NULL)
		{
			new_original = new_original->next;
			new_copy->next = new Node<T>(new_original->data, NULL);
			new_copy = new_copy->next;
		}
		while(front)
			serve();
		
		front = new_front;
		rear = new_copy;
	}
}

int main() {
	int test;
	cin >> test;
	while(test--) {
		int n;
		cin >> n;
		LinkedQueue<int> p;
		for(int i = 1; i <= n; i++)
			p.append(i);
		LinkedQueue<int> q = p;
		while(!q.isEmpty()) {
			int tmp;
			q.retrieve(tmp);
			cout << tmp << " ";
			q.serve();
			if(q.isEmpty())
				break;
			q.retrieve(tmp);
			q.append(tmp);
			q.serve();
		}
		cout << endl;
	}
	return 0;
}
