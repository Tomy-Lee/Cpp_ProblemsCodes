/*****************************************************************************
 *                                    graph.h
 *
 * Adjacency List Based Undirected Graph.
 *
 * This is a C++ template class for undirected graph with an adjacency list
 * representation. It provedes the general operations for graph, such as
 * insertVertex, removeVertex, insertEdge, removeEdge, getVertexNumber,
 * getEdgeNumber, getData, getWeight, getNextDst, and so on.
 *
 *
 * Chen Xiaonan   2011-12-25
 *****************************************************************************/


#include <iostream>
#include <string>
#include <cmath>
using namespace std;

/**
 *  graph's edge
 */
template<typename Weight>
struct Edge
{
	int				dst;		//terminal of certain edge
	Weight			cost;		//the weight of the edge
	Edge<Weight>	*next;		//point to the next edge

	Edge(int d, int c, Edge<Weight> *p = NULL)
		: dst(d), cost(c), next(p)
	{   }
};


/**
 *	graph's vertex
 */
template<typename Obj, typename Weight>
struct Vertex
{
	Obj				data;		//data of the vertex
	Edge<Weight>	*adj;

	Vertex(int d, Edge<Weight> *p = NULL)
		: data(d), adj(p)
	{   }
	Vertex()
	{   }
};


/**
 *	adjacency lists based graph
 */
template<typename Obj, typename Weight>
class WGraph
{
public:
	WGraph(int n);
	~WGraph();

	int getVertex() const;
	int getEdge() const;

	Obj getData(int i) const;
	int getIndex(const Obj &x) const;
	Weight getWeight(const Obj &x1, const Obj &x2) const;

	int getNextDst(const Obj &x) const;
	int getNextDst(const Obj &x1, const Obj &x2) const;

	void insertVertex(const Obj &x);
	void removeVertex(const Obj &x);
	void insertEdge(const Obj &x1, const Obj &x2, Weight c);
	void removeEdge(const Obj &x1, const Obj &x2);
	

private:
	int						vertex;		//number of vertices
	int						edge;		//number of edges
	int						maxSize;	//size of array, capacity of vertices
	Vertex<Obj, Weight>		*vArray;	//array of vertex
};

/*
 *	constructors and destructors
 */
template<typename Obj, typename Weight>
WGraph<Obj, Weight>::WGraph(int n)
{
	maxSize = n;
	vertex = 0;
	edge = 0;
	vArray = new Vertex<Obj, Weight>[maxSize];

	/*	initialize the array	*/
	for(int i = 0; i < maxSize; i++)
		vArray[i].adj = NULL;
}

template<typename Obj, typename Weight>
WGraph<Obj, Weight>::~WGraph()
{
	for(int i = 0; i < maxSize; i++)
	{
		/*	delete the nodes of every vertex respectively	*/
		Edge<Weight> *p = vArray[i].adj;
		while(p)
		{
			vArray[i].adj = p -> next;
			delete p;
			p = vArray[i].adj;
		}
	}

	delete []vArray;
}

/**
 *	get number of vertices
 */
template<typename Obj, typename Weight>
int WGraph<Obj, Weight>::getVertex() const
{
	return vertex;
}

/**
 *	get number of vertices
 */
template<typename Obj, typename Weight>
int WGraph<Obj, Weight>::getEdge() const
{
	return edge;
}

/**
 *	get the content of vertex 'i'
 */
template<typename Obj, typename Weight>
Obj WGraph<Obj, Weight>::getData(int i) const
{
	if(i >= 0 && i < vertex)
		return vArray[i].data;
}

/**
 *	get the index of vertex 'x'
 */
template<typename Obj, typename Weight>
int WGraph<Obj, Weight>::getIndex(const Obj &x) const
{
	for(int i = 0; i < vertex; i++)
		if(vArray[i].data == x)
			return i;
	return -1;
}

/**
 *	get the weight on the edge between 'x1' and 'x2'
 */
template<typename Obj, typename Weight>
Weight WGraph<Obj, Weight>::getWeight(const Obj &x1, const Obj &x2) const
{
    int v1 = getIndex(x1),
        v2 = getIndex(x2);

    if(v1 == -1)
        return Weight(0);
    else if(v2 == -1)
        return Weight(0);
    else
    {
        Edge<Weight> *p = vArray[v1].adj;
        while(p != NULL && p->dst != v2)
            p = p -> next;

        if(p != NULL)
            return p -> cost;
        else
            return Weight(0);
    }
}

/**
 *	given start point, get the terminal point 
 */
template<typename Obj, typename Weight>
int WGraph<Obj, Weight>::getNextDst(const Obj &x) const
{
	int index = getIndex(x);
	if(index != -1)
	{
		Edge<Weight> *p = vArray[index].adj;
		if(p)
			return p -> dst;
		else 
			return -1;
	}
}

/**
 *	given two vertices, get the next start point
 */
template<typename Obj, typename Weight>
int WGraph<Obj, Weight>::getNextDst(const Obj &x1, const Obj &x2) const
{
	int v1 = getIndex(x1),
		v2 = getIndex(x2);

	if(v1 == -1 || v2 == -1)
		return -1;
	else
	{
		Edge<Weight> *p = vArray[v1].adj;
		/*	find the terminal point	*/
		while(p && p -> dst != v2)
			p = p -> next;
		
		if(p && p -> next)
			return p -> next -> dst;
		else
			return -1;

	}
}

/**
 *	insert a vertex
 */
template<typename Obj, typename Weight>
void WGraph<Obj, Weight>::insertVertex(const Obj &x)
{
	if(vertex < maxSize)
		vArray[vertex++].data = x;
	else 
		return ;
}

/**
 *	remove a vertex
 */
template<typename Obj, typename Weight>
void WGraph<Obj, Weight>::removeVertex(const Obj &x)
{
	int terminal = 0,		//the terminal vertex's index
		v = getIndex(x);	//the index of the vertex to be deleted

	/*	not existed	*/
	if(v == -1)
		return ;
	/*	existed	*/
	else
	{
		Edge<Weight>	*cur_node,		 /*	point to the first edge 
											connected with 'vArray[v]'	*/
						*to_delete,		 /*	point to the edge(to be deleted) in 
											'vArray[terminal]' which connected with 'vAAray[v]'	*/
						*parent;		 /*	point to the the last node of 'to_delete'	*/

		while(vArray[v].adj != NULL)
		{
			cur_node = vArray[v].adj;
			terminal = cur_node->dst;

			to_delete = vArray[terminal].adj;
			parent = NULL;
			while(to_delete != NULL && to_delete->dst != v)
			{
				parent = to_delete;
				to_delete = to_delete->next;
			}
			if(parent != NULL)
				parent->next = to_delete->next;
			else
				vArray[terminal].adj = to_delete->next;
			delete to_delete;

			vArray[v].adj = cur_node->next;
			delete cur_node;
			edge--;
		}

		vArray[v] = vArray[--vertex];
		vArray[vertex].adj = NULL;

		cur_node = vArray[terminal].adj;
		while(cur_node != NULL)
		{
			to_delete = vArray[cur_node->dst].adj;
			while(parent != NULL)
			{
				if(parent->dst == vertex)
				{
					 parent->dst = v;
					 break;
				}
				else
					 parent = parent->next;
			}
			cur_node = cur_node->next;
		}
	}
}

/**
 *	insert an edge
 */
template<typename Obj, typename Weight>
void WGraph<Obj, Weight>::insertEdge(const Obj &x1, const Obj &x2, Weight c)
{
	int v1 = getIndex(x1),		//get the two vertices' index
		v2 = getIndex(x2);	
	/*	invalid vertex input	*/
	if(v1 == -1 || v2 == -1)
		return ;
	/*	valid vertex input	*/
	else
	{
		Edge<Weight> *p = vArray[v1].adj;	//get start point of the new edge
		/*	check if the edge already existed	*/
		while(p && p -> dst != v2)
			p = p -> next;
		if(p)
			return ;

		/*	insert the edge to the start point chain	*/
		vArray[v1].adj = new Edge<Weight>(v2, c, p);
		/*	insert the edge to the terminal point chain	*/
		p = vArray[v2].adj;
		vArray[v2].adj = new Edge<Weight>(v1, c, p);
		
		edge++;	//add one to the edge
	}
}

/**
 *	remove an edge
 */
template<typename Obj, typename Weight>
void WGraph<Obj, Weight>::removeEdge(const Obj &x1, const Obj &x2)
{
	int v1 = getIndex(x1),		//get the two vertices' index
		v2 = getIndex(x2);

	/*	invalid vertex input	*/
	if(v1 == -1 || v2 == -1)
		return ;
	/*	valid vertex input	*/
	else
	{
		/*	check if the edge existed*/
		Edge<Weight> *p = vArray[v1].adj,	//point to the edge to be deleted
					*parent = NULL;			//point to the last edge to be deleted
		/*	find the edge to be deleted*/
		while(p && p -> dst != v2)
		{
			parent = p;
			p = p -> next;
		}
		/*	not existed, return	*/
		if(!p)
			return ;
		/*	existed, remove the edge, 2 situations	*/
		else if(!parent)
			vArray[v1].adj = p -> next;
		else
			parent -> next = p -> next;
		delete p;
		
		/*	delete the edge connected with the terminal point, a repeated operation	*/
		p = vArray[v2].adj;
		parent = NULL;
		while(p && p -> dst != v1)
		{
			parent = p;
			p = p -> next;
		}
		if(!p)
			return ;
		else if(!parent)
			vArray[v2].adj = p -> next;
		else
			parent -> next = p -> next;
		delete p;

		/*	do not forget to subtract one from the edge	*/
		edge--;
	}
}

/**
 * Reload the "<<" operator.
 */
template<typename Obj, typename Weight>
ostream& operator<<(ostream &out, const WGraph<Obj,Weight> &g)
{
    int verNum = g.getVertex(),
        edgeNum = g.getEdge();

    out << "This graph has " << verNum 
		<< " vertexes and " << edgeNum << " edges." << endl;
    for(int i = 0; i < verNum; i++)
    {
        Obj x1 = g.getData(i);
        out << x1 << " :    ";
        int j = g.getNextDst(x1);
        if(j != -1)
        {
            Obj x2 = g.getData(j);
            out << "( " << x1 << ", " << x2 << ", " 
				<< g.getWeight(x1, x2) << " )" << "    ";
            do
            {
                j = g.getNextDst(x1, x2);
                if(j != -1)
                {
                    x2 = g.getData(j);
                    out << "( " << x1 << ", " << x2 << ", " 
						<< g.getWeight(x1,x2) << " )" << "    ";
                }
                else
                    break;
            }
            while(j != -1);
        }
        out << endl;
    }
    return out;
}
