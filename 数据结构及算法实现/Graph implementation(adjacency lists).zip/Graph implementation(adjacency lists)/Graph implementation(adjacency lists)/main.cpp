/*****************************************************************************
 *                               graph_test.cpp
 *
 * Adjacency List Based Undirected Graph testing.
 *
 * Chen Xiaonan  2011-12-26
 *****************************************************************************/



#include <iostream>
#include "graph.h"


using namespace std;



int main()
{
    WGraph<char, int> g( 5 );

    g.insertVertex( 'A' );
    g.insertVertex( 'B' );
    g.insertVertex( 'C' );
    g.insertVertex( 'D' );
    cout << g << endl << endl;

    g.insertEdge( 'A', 'B', 4 );
    g.insertEdge( 'A', 'C', 2 );
    g.insertEdge( 'B', 'D', 3 );
    cout << g << endl << endl;

    g.removeEdge( 'A', 'B' );
    cout << g << endl << endl;

    g.removeVertex('B');
    cout << g << endl << endl;

    g.removeEdge( 'A', 'B' );
    cout << g << endl << endl;

    g.removeVertex('B');
    cout << g << endl;
	
	system("pause");
    return 0;
}

